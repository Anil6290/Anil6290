export interface Crop {
  id: string;
  name: string;
  category: string;
  growthPeriod: number; // in days
  idealTemperature: {
    min: number;
    max: number;
  };
  waterRequirements: 'low' | 'medium' | 'high';
  soilType: string[];
  description: string;
  imageUrl: string;
}

export interface CropListing {
  id: string;
  cropId: string;
  farmerId: string;
  quantity: number;
  price: number;
  harvestDate: string;
  location: string;
  status: 'available' | 'sold' | 'reserved';
}

export interface CropSuggestion {
  cropId: string;
  confidence: number;
  reason: string;
}
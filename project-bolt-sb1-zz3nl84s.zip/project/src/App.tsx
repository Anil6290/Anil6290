import React from 'react';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { CropGuide } from './components/CropGuide';
import { Marketplace } from './components/Marketplace';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <main>
        <Dashboard />
        <CropGuide />
        <Marketplace />
      </main>
    </div>
  );
}

export default App;
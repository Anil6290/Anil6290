import React from 'react';
import { Sun, Droplets, Wind, Calendar } from 'lucide-react';

export function Dashboard() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Welcome back, Farmer</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <WeatherCard
          icon={<Sun className="h-8 w-8 text-yellow-500" />}
          title="Temperature"
          value="24°C"
          description="Partly cloudy"
        />
        <WeatherCard
          icon={<Droplets className="h-8 w-8 text-blue-500" />}
          title="Humidity"
          value="65%"
          description="Optimal for crops"
        />
        <WeatherCard
          icon={<Wind className="h-8 w-8 text-gray-500" />}
          title="Wind Speed"
          value="12 km/h"
          description="Light breeze"
        />
        <WeatherCard
          icon={<Calendar className="h-8 w-8 text-green-500" />}
          title="Next Harvest"
          value="15 days"
          description="Wheat field"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Active Crops</h2>
          <div className="space-y-4">
            {['Wheat', 'Corn', 'Soybeans'].map((crop) => (
              <div key={crop} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <span className="font-medium">{crop}</span>
                <div className="flex items-center space-x-4">
                  <span className="text-green-600">Growing</span>
                  <button className="text-blue-600 hover:underline">Details</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Crop Suggestions</h2>
          <div className="space-y-4">
            {[
              { crop: 'Tomatoes', confidence: 95 },
              { crop: 'Potatoes', confidence: 88 },
              { crop: 'Carrots', confidence: 82 },
            ].map((item) => (
              <div key={item.crop} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <span className="font-medium">{item.crop}</span>
                <div className="flex items-center space-x-4">
                  <span className="text-green-600">{item.confidence}% match</span>
                  <button className="text-blue-600 hover:underline">Learn More</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function WeatherCard({ icon, title, value, description }: {
  icon: React.ReactNode;
  title: string;
  value: string;
  description: string;
}) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        {icon}
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
      </div>
      <div className="text-2xl font-bold text-gray-900 mb-2">{value}</div>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}
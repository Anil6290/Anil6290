import React from 'react';
import { Menu, Home, Sprout, ShoppingBag, LineChart, Info } from 'lucide-react';

export function Navigation() {
  return (
    <nav className="bg-green-700 text-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <div className="flex items-center">
              <Sprout className="h-8 w-8" />
              <span className="ml-2 text-xl font-bold">FarmWise</span>
            </div>
            
            <div className="hidden md:flex space-x-6">
              <NavLink icon={<Home className="h-5 w-5" />} text="Dashboard" />
              <NavLink icon={<Sprout className="h-5 w-5" />} text="My Crops" />
              <NavLink icon={<ShoppingBag className="h-5 w-5" />} text="Marketplace" />
              <NavLink icon={<LineChart className="h-5 w-5" />} text="Analytics" />
              <NavLink icon={<Info className="h-5 w-5" />} text="Crop Guide" />
            </div>
          </div>
          
          <div className="md:hidden">
            <button className="p-2 rounded-md hover:bg-green-600">
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavLink({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <a href="#" className="flex items-center space-x-2 hover:text-green-200 transition-colors">
      {icon}
      <span>{text}</span>
    </a>
  );
}
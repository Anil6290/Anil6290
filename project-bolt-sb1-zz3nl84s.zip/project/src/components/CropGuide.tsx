import React from 'react';
import { Search, Filter } from 'lucide-react';

export function CropGuide() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-4 md:mb-0">Crop Encyclopedia</h1>
        
        <div className="flex space-x-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search crops..."
              className="pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          
          <button className="flex items-center space-x-2 px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200">
            <Filter className="h-5 w-5" />
            <span>Filter</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {crops.map((crop) => (
          <CropCard key={crop.id} {...crop} />
        ))}
      </div>
    </div>
  );
}

function CropCard({ name, imageUrl, description }: { name: string; imageUrl: string; description: string }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img src={imageUrl} alt={name} className="w-full h-48 object-cover" />
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2">{name}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <button className="text-green-600 hover:text-green-700 font-medium">
          Learn More →
        </button>
      </div>
    </div>
  );
}

const crops = [
  {
    id: '1',
    name: 'Wheat',
    imageUrl: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=800',
    description: 'A cereal grain that is a worldwide staple food.',
  },
  {
    id: '2',
    name: 'Rice',
    imageUrl: 'https://images.unsplash.com/photo-1536304447766-da0ed4ce1b73?auto=format&fit=crop&w=800',
    description: 'The most widely consumed staple food for a large part of the world.',
  },
  {
    id: '3',
    name: 'Corn',
    imageUrl: 'https://images.unsplash.com/photo-1601593768799-76d3bc7c8607?auto=format&fit=crop&w=800',
    description: 'A cereal grain first domesticated by indigenous peoples in Mexico.',
  },
];